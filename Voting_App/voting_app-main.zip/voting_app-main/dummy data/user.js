[
    {
        "name": "Ravi Kumar",
        "age": 30,
        "mobile": "9876543210",
        "email": "ravi@example.com",
        "address": "123, ABC Street, XYZ City",
        "aadharCardNumber": 123456789012,
        "password": "password123"
    },
    {
        "name": "Sita Devi",
        "age": 28,
        "mobile": "8765432109",
        "email": "sita@example.com",
        "address": "456, PQR Street, LMN City",
        "aadharCardNumber": 234567890123,
        "password": "password456"
    },
    {
        "name": "Amit Singh",
        "age": 35,
        "mobile": "7654321098",
        "email": "amit@example.com",
        "address": "789, DEF Street, UVW City",
        "aadharCardNumber": 345678901234,
        "password": "password789",
        "role": "admin"
    },
    {
        "name": "Priya Sharma",
        "age": 25,
        "mobile": "6543210987",
        "email": "priya@example.com",
        "address": "321, GHI Street, OPQ City",
        "aadharCardNumber": 456789012345,
        "password": "password123"
    },
    {
        "name": "Arun Patel",
        "age": 40,
        "mobile": "5432109876",
        "email": "arun@example.com",
        "address": "654, JKL Street, RST City",
        "aadharCardNumber": 567890123456,
        "password": "password456"
    },
    {
        "name": "Suresh Verma",
        "age": 32,
        "mobile": "4321098765",
        "email": "suresh@example.com",
        "address": "987, MNO Street, UVW City",
        "aadharCardNumber": 678901234567,
        "password": "password789"
    }
]
