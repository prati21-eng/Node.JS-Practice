[
    {
        "name": "Narendra Modi",
        "party": "BJP",
        "age": 71
    },
    {
        "name": "Rahul Gandhi",
        "party": "INC",
        "age": 51
    },
    {
        "name": "Arvind Kejriwal",
        "party": "AAP",
        "age": 53
    },
    {
        "name": "Mamata Banerjee",
        "party": "AITC",
        "age": 67
    },
    {
        "name": "Yogi Adityanath",
        "party": "BJP",
        "age": 49
    }
]